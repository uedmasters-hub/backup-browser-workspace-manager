(function(){function e(e,t=`Quick note`){let n=e.replace(/\r\n/g,`
`).split(`
`),r=e.trim().length>0?n:[``],i=Date.now();return{id:crypto.randomUUID(),title:(t.trim()||`Quick note`).slice(0,100),blocks:r.map(e=>({id:crypto.randomUUID(),type:`text`,text:e})),createdAt:i,updatedAt:i}}var t=`floaterEnabled`,n=`floaterNotes`,r=`workspaceNotes`,i=264;function a(e){return e<=0?`Quick note`:`Quick note ${e+1}`}var o=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8M7 3v5h8"/></svg>`,s=null,c=null,l=[],u=new Map,d=null,f=null,p;function m(e,t){let n=Math.max(8,window.innerWidth-i-8),r=Math.max(8,window.innerHeight-230-8);return{left:Math.min(Math.max(8,e),n),top:Math.min(Math.max(8,t),r)}}function h(e){return m(window.innerWidth-i-24-e*26,window.innerHeight-280+e*26)}function g(e,t){let n=t?m(t.left+28,t.top+28):h(e);return{id:crypto.randomUUID(),text:``,left:n.left,top:n.top}}function _(){p&&window.clearTimeout(p),p=window.setTimeout(()=>{chrome.storage.local.set({[n]:l})},200)}async function v(t,n){if(!t.trim())return!1;let i=await chrome.storage.local.get(r),a=Array.isArray(i[r])?i[r]:[];return a.unshift(e(t,n)),await chrome.storage.local.set({[r]:a}),!0}function y(){let e=document.createElement(`style`);return e.textContent=`
    :host { all: initial; }
    .layer {
      position: fixed; inset: 0; pointer-events: none;
      font-family: Inter, system-ui, -apple-system, sans-serif;
    }
    .card {
      position: absolute;
      width: ${i}px;
      pointer-events: auto;
      background: #ffffff;
      border-radius: 16px;
      box-shadow: 0 10px 34px rgba(15, 23, 42, 0.18),
        0 2px 8px rgba(15, 23, 42, 0.08);
      overflow: hidden;
      border: 1px solid rgba(15, 23, 42, 0.06);
    }
    .header {
      display: flex; align-items: center; gap: 3px;
      padding: 10px 6px 8px 12px; cursor: grab; user-select: none;
    }
    .header:active { cursor: grabbing; }
    .dot {
      width: 7px; height: 7px; border-radius: 9999px;
      background: #f59e0b; flex: 0 0 auto;
    }
    .label {
      font-size: 12.5px; font-weight: 600; color: #404040;
      flex: 1 1 auto; min-width: 0; letter-spacing: 0.01em;
      overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }
    .icon {
      width: 25px; height: 25px; border: none; background: transparent;
      color: #a3a3a3; border-radius: 8px; cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      padding: 0; flex: 0 0 auto;
      transition: background 0.15s, color 0.15s;
    }
    .icon:hover { background: #f5f5f5; color: #404040; }
    .icon svg { width: 15px; height: 15px; }
    .icon.save:hover { color: #059669; }
    .icon.saved { color: #059669; }
    textarea {
      display: block; width: 100%; box-sizing: border-box;
      min-height: 132px; max-height: 320px; resize: vertical;
      border: none; outline: none; padding: 2px 14px 14px 14px;
      font-size: 13px; line-height: 1.55; color: #171717;
      background: transparent; font-family: inherit;
    }
    textarea::placeholder { color: #cbcbcb; }
  `,e}function b(e,t,n){let r=document.createElement(`button`);return r.className=`icon ${e}`.trim(),r.type=`button`,r.title=t,r.setAttribute(`aria-label`,t),r.innerHTML=n,r}function x(e){let t=document.createElement(`div`);t.className=`card`,t.style.left=`${e.left}px`,t.style.top=`${e.top}px`,t.addEventListener(`pointerdown`,e=>e.stopPropagation()),t.addEventListener(`mousedown`,e=>e.stopPropagation()),t.addEventListener(`click`,e=>e.stopPropagation());let n=document.createElement(`div`);n.className=`header`;let r=document.createElement(`span`);r.className=`dot`;let i=document.createElement(`span`);i.className=`label`,i.textContent=`Quick note`;let s=b(``,`Stack notes by name`,`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="8" y="3" width="13" height="13" rx="2"/><path d="M16 16v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-9a2 2 0 0 1 2-2h3"/></svg>`),c=b(``,`New note`,`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>`),u=b(`save`,`Save to Notes`,o),p=b(`close`,`Hide this note`,`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>`);n.append(r,i,s,c,u,p);let h=document.createElement(`textarea`);h.placeholder=`Jot something down…`,h.value=e.text,h.spellcheck=!1,h.addEventListener(`input`,()=>{d=e.id;let t=l.find(t=>t.id===e.id);t&&(t.text=h.value),_()}),h.addEventListener(`blur`,()=>{d===e.id&&(d=null)}),[`keydown`,`keyup`,`keypress`,`input`,`beforeinput`,`paste`,`cut`,`copy`].forEach(e=>h.addEventListener(e,e=>e.stopPropagation())),t.append(n,h);let g={el:t,textarea:h,saveBtn:u,label:i};s.addEventListener(`click`,()=>{C()}),c.addEventListener(`click`,()=>{w(e.id)}),p.addEventListener(`click`,()=>{T(e.id)}),u.addEventListener(`click`,async()=>{let t=l.findIndex(t=>t.id===e.id);await v(h.value,a(t))&&(u.innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>`,u.classList.add(`saved`),g.savedTimer&&window.clearTimeout(g.savedTimer),g.savedTimer=window.setTimeout(()=>{u.innerHTML=o,u.classList.remove(`saved`)},1400))});let y=0,x=0,S=0,E=0,D=n=>{if(f!==e.id)return;let r=m(S+(n.clientX-y),E+(n.clientY-x));t.style.left=`${r.left}px`,t.style.top=`${r.top}px`},O=()=>{if(f!==e.id)return;f=null,window.removeEventListener(`pointermove`,D),window.removeEventListener(`pointerup`,O);let n=l.find(t=>t.id===e.id);n&&(n.left=parseFloat(t.style.left)||0,n.top=parseFloat(t.style.top)||0,_())};return n.addEventListener(`pointerdown`,n=>{n.target.closest(`.icon`)||(f=e.id,y=n.clientX,x=n.clientY,S=parseFloat(t.style.left)||0,E=parseFloat(t.style.top)||0,window.addEventListener(`pointermove`,D),window.addEventListener(`pointerup`,O))}),g}function S(){if(!c)return;let e=new Set(l.map(e=>e.id));for(let[t,n]of u)e.has(t)||(n.el.remove(),u.delete(t));for(let e of l){let t=u.get(e.id);if(t||(t=x(e),u.set(e.id,t),c.appendChild(t.el)),t.label.textContent=a(l.indexOf(e)),f!==e.id){let n=m(e.left,e.top);t.el.style.left=`${n.left}px`,t.el.style.top=`${n.top}px`}d!==e.id&&t.textarea.value!==e.text&&(t.textarea.value=e.text)}}function C(){l.forEach((e,t)=>{let n=m(36+t*30,72+t*30);e.left=n.left,e.top=n.top}),_(),S()}async function w(e){let t=e?l.find(t=>t.id===e):void 0,n=g(l.length,t);l.push(n),_(),S(),u.get(n.id)?.textarea.focus()}async function T(e){if(l=l.filter(t=>t.id!==e),l.length===0){await chrome.storage.local.set({[n]:[],[t]:!1});return}_(),S()}async function E(){if(s)return;let e=await chrome.storage.local.get(n);l=Array.isArray(e[n])?e[n]:[],s=document.createElement(`div`),s.id=`bwm-note-floater`,s.style.position=`fixed`,s.style.inset=`0`,s.style.zIndex=`2147483647`,s.style.pointerEvents=`none`;let t=s.attachShadow({mode:`open`});c=document.createElement(`div`),c.className=`layer`,t.append(y(),c),document.documentElement.appendChild(s),S()}function D(){p&&window.clearTimeout(p),u.clear(),s?.remove(),s=null,c=null,d=null,f=null}async function O(){if(window.top!==window.self)return;let{[t]:e}=await chrome.storage.local.get(t);e&&await E(),chrome.storage.onChanged.addListener((e,r)=>{if(r===`local`&&(t in e&&(e[t].newValue?E():D()),n in e&&s)){let t=e[n].newValue;l=Array.isArray(t)?t:[],S()}}),window.addEventListener(`resize`,()=>{s&&S()})}var k=window;k.__bwmFloaterInit||(k.__bwmFloaterInit=!0,O());})()
